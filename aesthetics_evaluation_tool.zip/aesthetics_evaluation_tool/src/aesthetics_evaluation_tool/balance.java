package aesthetics_evaluation_tool;

import java.text.DecimalFormat;

public class balance {
public static double value=0;
	public double balance() {
		// TODO Auto-generated constructor stub
		
		
		
		int w_UL= Sorting.wf_UL;
		int w_UR=Sorting.wf_UR;
		int w_LL=Sorting.wf_LL;
		int w_LR=Sorting.wf_LR;
		/*int w_UL= Sorting.w_UL;
		int w_UR=Sorting.w_UR;
		int w_LL=Sorting.w_LL;
		int w_LR=Sorting.w_LR;*/
		/* System.out.println("UL"+w_UL);
	      System.out.println("UR"+w_UR);
	      System.out.println("LL"+w_LL);
	      System.out.println("LR"+w_LR);
	      */
	      
		//calculates the balance considering the four quadrants
		
	    /*  int BMVleft=w_UL+w_LL;
	      int BMVright=w_UR+w_LR;
	      int BMV1= Math.abs((BMVleft-BMVright));
	      double BMV=0;
	      if (BMVleft>BMVright)
	      {
	    	   BMV=Math.abs((BMVleft-BMVright)/(double)BMVleft);
	      }
	      else
	      {
	    	  BMV=Math.abs((BMVleft-BMVright)/(double)BMVright);
	      }
	      
	      int BMHleft=w_UL+w_UR;
	      int BMHright=w_LL+w_LR;
	      int BMH1= Math.abs((BMVleft-BMVright));
	      double BMH=0;
	      if (BMHleft>BMHright)
	      {
	    	   BMH=Math.abs((BMHleft-BMHright)/(double)BMHleft);
	      }
	      else
	      {
	    	  BMH=Math.abs((BMHleft-BMHright)/(double)BMHright);
	      }*/
	      
	      
	      //int BMH= Math.abs((w_UL+w_UR)-(w_LL+w_LR)); 
	      //System.out.println(BMV);
	      //System.out.println(BMH);
	      
		
		//calculates the balance considering two quadrants
		
		
		int BMV1=Math.abs(w_UL-w_UR);
	     
	     
	      double BMV=0;
	      if (w_UL>w_UR)
	      {
	    	   BMV=Math.abs((w_UL-w_UR)/(double)(w_UL));
	      }
	      else if (w_UL==0 || w_UR==0)
	      {
	    	  BMV=0;
	      }
	      else
	      {
	    	  BMV=Math.abs((w_UL-w_UR)/(double)(w_UR));
	      }
	     // System.out.println(BMV);
	      int BMH1=w_LL-w_LR;
	      double BMH=0;
	      if (w_LL>w_LR)
	      {
	    	   BMH=Math.abs((w_LL-w_LR)/(double)(w_LL));
	      }
	      else if (w_LL==0 || w_LR==0)
	      {
	    	  BMH=0;
	      }
	      else
	      {
	    	  BMH=Math.abs((w_LL-w_LR)/(double)(w_LR));
	      }
	      
	      //System.out.println(BMH); 
	    
		
	      double balance=(1- (BMV+BMH)/2);
	     // System.out.println(balance);
	       value =Double.parseDouble(new DecimalFormat("##.###").format(balance));
	       if (Math.abs(value)>=1)
			 {
				 value=1;
			 }
			return Math.abs(value);
		
		
		
		
		
		
		
		
		
		
		
	}

}
