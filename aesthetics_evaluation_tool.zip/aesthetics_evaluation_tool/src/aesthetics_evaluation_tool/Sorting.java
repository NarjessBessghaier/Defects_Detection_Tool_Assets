package aesthetics_evaluation_tool;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.Arrays;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class Sorting {
	public static int ULnew=0;
	public static int URnew=0;
	public static int LLnew=0;
	public static int LRnew=0;
	public static int w_UL=0;
	public static int w_UR=0;
	public static int w_LL=0;
	public static int w_LR=0;
	public static int wf_UL=0;
	public static int wf_UR=0;
	public static int wf_LL=0;
	public static int wf_LR=0;
	public static double value=0;
	public double Sorting() throws IOException {
		// TODO Auto-generated constructor stub
		
		
		int indice_X=0;
		int indice_Y=0;
		int indice_width=0;
		int indice_height=0;
				//main_launcher ML= new main_launcher();
		    	String file=main_launcher.data_File;
		    	
		    	InputStream input = new FileInputStream(file);
				 HSSFWorkbook wb     = new HSSFWorkbook(input);
				 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
				 //row number
				 int rowTotal = sheet.getLastRowNum();
			
		      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
		          rowTotal++;
		      }
		    	
		      for ( int r=0;r<1; r++){     
					 HSSFRow row     = sheet.getRow(r); 
					 
					 //get cell number in each row
					 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
					 
					 // parse cells values of each row
					 for (int c=0;c<noOfColumns; c++)
			    	        
				        {
						 
					 HSSFCell cell= row.getCell(c);
					// System.out.println("row="+r+"###"+cell.getStringCellValue() );
					 
					 String text= cell.getStringCellValue();
					 //System.out.println("text="+text);
					 if (text.equals("x"))
					 {
						indice_X=c; 
						//System.out.println(indice_width);
					 }
					 
					 if (text.equals("y"))
					 {
						indice_Y=c; 
						//System.out.println(indice_height);
					 } 
					 if (text.equals("width"))
					 {
						indice_width=c; 
						//System.out.println(indice_width);
					 }
					 
					 if (text.equals("height"))
					 {
						indice_height=c; 
						//System.out.println(indice_height);
					 } 
				        }
					 }
		      
		      int [] Xtab=new int[rowTotal]; 
			  int [] Ytab=new int[rowTotal]; 
			  int [] width=new int[rowTotal]; 
			  int [] height=new int[rowTotal]; 
			 
			  
		      for ( int r=1;r<rowTotal; r++)
		      
		      {   
		    	  HSSFRow row     = sheet.getRow(r); 
		    	  
		    	  //fill the X table
		    	  for (int c=indice_X;c<indice_X+1; c++)
		  	        
			        {
		    		  HSSFCell cell= row.getCell(c);
		    		  cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
		    		  Xtab[r-1]= (int)(cell.getNumericCellValue());
		    		 
			        }
		    	  
		    	  
		    	//fill the Y table
		    	  
		    	  for (int c=indice_Y;c<indice_Y+1; c++)
		    	        
			        {
		  		  HSSFCell cell= row.getCell(c);
		  		  cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
		  		  Ytab[r-1]= (int)(cell.getNumericCellValue());
		  		
			        }
		    	//fill the width table
		    	  for (int c=indice_width;c<indice_width+1; c++)
		  	        
			        {
		    		  HSSFCell cell= row.getCell(c);
		    		  cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
		    		  width[r-1]= (int)(cell.getNumericCellValue());
		    		  
			        }
		    	  
		    	//fill the height table
		    	  
		    	  for (int c=indice_height;c<indice_height+1; c++)
		    	        
			        {
		  		  HSSFCell cell= row.getCell(c);
		  		  cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
		  		  height[r-1]= (int)(cell.getNumericCellValue());
		  		  
			        }
		      }
		      
		      //afficher xtab et ytab
		      for (int k = 0; k < Xtab.length-1; ++k) { 
		  			//System.out.println("vals dans xtab=="+Xtab[k]);
		  			
		  		}
		     //System.out.println("***********************");
		      for (int k = 0; k < Ytab.length-1; ++k) { 
		  			//System.out.println("vals dans ytab=="+Ytab[k]);
		  			
		  		}
		     // System.out.println("***********************");
		      
		      
		      
		      //diviser area sur 2
		      
		     int newheight=main_launcher.Frameheight/2;
		      int newwidth=main_launcher.Framewidth/2;
		      
		      //System.out.println(newheight);
		      //System.out.println(newwidth);
		      
		      //System.out.println("***********************");
		      
		      //tester l'existance de composants dans chaque groupe area
		      
		    int UL=0;
		  	 int UR=0;
		  	 int LL=0;
		  	 int LR=0;
		     
		      
		      for (int k = 0; k < Xtab.length; ++k) { 
		  			
		  			int x= Xtab[k];
		  			int y=Ytab[k];
		  			//System.out.println(x);
				      //System.out.println(y);
		  			if (y<newwidth & x<newheight)
		  			{
		  				UL++;
		  			
		  				ULnew++;
		  				w_UL=w_UL+((int)width[k]*(int)height[k]);
		  				wf_UL=wf_UL+(((int)width[k]*(int)height[k])*(x));
		  			}
		  			else if (y>=newwidth & x<newheight)
		  			{
		  				UR++;
		  				
		  				URnew++;
		  				w_UR=w_UR+((int)width[k]*(int)height[k]);
		  				wf_UR=wf_UR+(((int)width[k]*(int)height[k])*(x));
		  			}
		  			
		  			else if (y<newwidth & x>=newheight)
		  			{
		  				LL++;
		  				
		  				LLnew++;
		  				w_LL=w_LL+((int)width[k]*(int)height[k]);
		  				wf_LL=wf_LL+(((int)width[k]*(int)height[k])*(x));
		  			}
		  			else if (y>=newwidth & x>=newheight){
		  				LR++;
		  			
		  				LRnew++;
		  				w_LR=w_LR+((int)width[k]*(int)height[k]);
		  				wf_LR=wf_LR+(((int)width[k]*(int)height[k])*(x));
		  			}
		  		}   
		      
		  /*  System.out.println("UL"+UL);
		      System.out.println("UR"+UR);
		      System.out.println("LL"+LL);
		      System.out.println("LR"+LR);*/
		     
		/*   System.out.println("UL"+w_UL);
		      System.out.println("UR"+w_UR);
		      System.out.println("LL"+w_LL);
		      System.out.println("LR"+w_LR);*/
		      
		      
		      
		      int dimension4=0;
		      int dimension3=0;
		      int dimension2=0;
		      int dimension1=0;
		      int[] tab_tri= new int [4];
		      tab_tri[0]=w_UL;
		      tab_tri[1]=w_UR;
		      tab_tri[2]=w_LL;
		      tab_tri[3]=w_LR;
		      
		      Arrays.sort(tab_tri);
		      
		      for (int k = 0; k < tab_tri.length; ++k) 
		      {
		    	  //System.out.println(tab_tri[k]);
		      } 
		      
		      
		       //dimension4
		    	  if (tab_tri[3]==w_UL)
		    	  {
		    		  dimension4=4*UL;
		    		 
		    	  }
		    	  
		    	  else if (tab_tri[3]==w_UR)
		    	  {
		    		  dimension4=4*UR;
		    		 
		    	  }
		    	  
		    	  else if (tab_tri[3]==w_LL)
		    	  {
		    		  dimension4=4*LL;
		    		 
		    	  }
		    	  else 
		    	  {
		    		  dimension4=4*LR;
		    		  
		    	  }
		    	  
		     
		    	  //dimension3
		    	  if (tab_tri[2]==w_UL)
		    	  {
		    		  dimension3=3*UL;
		    		 
		    	  }
		    	  
		    	  else if (tab_tri[2]==w_UR)
		    	  {
		    		  dimension3=3*UR;
		    		 
		    	  }
		    	  
		    	  else if (tab_tri[2]==w_LL)
		    	  {
		    		  dimension3=3*LL;
		    		 
		    	  }
		    	  else 
		    	  {
		    		  dimension3=3*LR;
		    		 
		    	  }
		    	  
		      
		    	  //dimension2
		    	  if (tab_tri[1]==w_UL)
		    	  {
		    		  dimension2=2*UL;
		    		 
		    	  }
		    	  
		    	  else if (tab_tri[1]==w_UR)
		    	  {
		    		  dimension2=2*UR;
		    		
		    	  }
		    	  
		    	  else if (tab_tri[1]==w_LL)
		    	  {
		    		  dimension2=2*LL;
		    		 
		    	  }
		    	  else 
		    	  {
		    		  dimension2=2*LR;
		    		  
		    	  }
		    	  
		      
		    	  //dimension1
		    	  if (tab_tri[0]==w_UL)
		    	  {
		    		  dimension1=1*UL;
		    	  }
		    	  
		    	  else if (tab_tri[0]==w_UR)
		    	  {
		    		  dimension1=1*UR;
		    	  }
		    	  
		    	  else if (tab_tri[0]==w_LL)
		    	  {
		    		  dimension1=1*LL;
		    	  }
		    	  else 
		    	  {
		    		  dimension1=1*LR;
		    	  }
		    	  
		    	 
		     
		      
		      
		      double sorting= Math.abs(1-(( (double)(dimension4)+(double)(dimension3)+(double)(dimension2)+(double)(dimension1) )/(double)(4*(rowTotal-1))));
		     value =Double.parseDouble(new DecimalFormat("##.###").format(sorting));
		     if (Math.abs(value)>=1)
		     {
		    	 value=1;
		     }
			return Math.abs(value);
		
		
		
		
		
		
		
		
		
		
		
	}

}
